import { ConfirmButton } from "../../app/type";

// 定义 ConfirmButton 类型的常量
export const _confirmButton: ConfirmButton = {
  show: true,
  hasButton: true,
  closeButton: true,
};
