//@ts-ignore
export default function sendTo3d(options: any) {
  console.log(options);
}
